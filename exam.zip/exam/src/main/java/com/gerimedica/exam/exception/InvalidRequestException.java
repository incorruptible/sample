package com.gerimedica.exam.exception;

public class InvalidRequestException extends CustomException {

    public static final int ERROR_CODE = 1000;

    public InvalidRequestException(String message) {
        super(ERROR_CODE, message);
    }
}
