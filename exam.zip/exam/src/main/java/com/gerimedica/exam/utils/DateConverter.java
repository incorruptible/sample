package com.gerimedica.exam.utils;

import com.opencsv.bean.AbstractBeanField;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateConverter extends AbstractBeanField<String, Date> {

    @Override
    public Date convert(String value) {
        if (StringUtils.isNotEmpty(value)) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            try {
                return sdf.parse(value);
            } catch (ParseException e) {
                throw new IllegalArgumentException("Invalid date format: " + value);
            }
        }
        return null;
    }
}
