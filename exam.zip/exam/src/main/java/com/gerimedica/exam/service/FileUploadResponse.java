package com.gerimedica.exam.service;

public class FileUploadResponse {

    private String name;

    public FileUploadResponse(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
