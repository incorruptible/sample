package com.gerimedica.exam.service;

import com.gerimedica.exam.model.PatientRecord;
import com.gerimedica.exam.repository.PatientRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientRecordService {

    @Autowired
    private PatientRecordRepository patientRecordRepository;

    public List<PatientRecord> getRecords() {
        return patientRecordRepository.findAll();
    }

    public PatientRecord getByCode(String code) {
        return patientRecordRepository.findByCode(code);
    }

    public void deleteAllRecords() {
        patientRecordRepository.deleteAll();
    }

}
