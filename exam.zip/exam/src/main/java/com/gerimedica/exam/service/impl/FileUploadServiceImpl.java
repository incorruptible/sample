package com.gerimedica.exam.service.impl;

import com.gerimedica.exam.exception.InvalidRequestException;
import com.gerimedica.exam.model.PatientRecord;
import com.gerimedica.exam.repository.PatientRecordRepository;
import com.gerimedica.exam.service.FileUploadResponse;
import com.gerimedica.exam.service.FileUploadService;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

@Service
public class FileUploadServiceImpl implements FileUploadService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadServiceImpl.class);

    private static final String CSV_TYPE = "text/csv";

    @Autowired
    private PatientRecordRepository patientRepository;

    @Override
    public FileUploadResponse upload(MultipartFile file) {
        if (file == null)
            throw new InvalidRequestException("File is empty");
        if (!CSV_TYPE.equals(file.getContentType())) {
            throw new InvalidRequestException("Invalid file type");
        }
        LOGGER.info("Received file with name [{}]", file.getOriginalFilename());
        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {

            // create csv bean reader
            CsvToBean<PatientRecord> csvToBean = new CsvToBeanBuilder(reader)
                    .withType(PatientRecord.class)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();

            List<PatientRecord> patientRecords = csvToBean.parse();

            patientRepository.saveAll(patientRecords);
            LOGGER.info("Patient records: {}", patientRecords.size());
        } catch (Exception e) {

        }
        return new FileUploadResponse(file.getOriginalFilename());
    }
}
