package com.gerimedica.exam.controller;

import com.gerimedica.exam.model.PatientRecord;
import com.gerimedica.exam.service.FileUploadResponse;
import com.gerimedica.exam.service.FileUploadService;
import com.gerimedica.exam.service.PatientRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/record")
public class PatientRecordController {

    @Autowired
    private PatientRecordService patientRecordService;

    @Autowired
    private FileUploadService fileUploadService;

    @RequestMapping("/upload")
    @PostMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<FileUploadResponse> uploadPatientData(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(fileUploadService.upload(file));
    }

    @GetMapping
    public ResponseEntity<List<PatientRecord>> fetchAll() {
        return ResponseEntity.ok(patientRecordService.getRecords());
    }

    @GetMapping("/{code}")
    public ResponseEntity<PatientRecord> fetchByCode(@PathVariable String code) {
        PatientRecord patientRecord = patientRecordService.getByCode(code);
        if (patientRecord == null)
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok(patientRecord);
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllRecords() {
        patientRecordService.deleteAllRecords();
        return ResponseEntity.noContent().build();
    }

}
