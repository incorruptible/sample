package com.gerimedica.exam;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Date;

@SpringBootApplication
public class ExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamApplication.class, args);
		DateTimeConverter dateConverter = new DateConverter(null);
		dateConverter.setPatterns(new String[]{"dd-MM-yyyy"});
// or just use: dateConverter.setPattern("MM/dd/yyyy")
		ConvertUtils.register(dateConverter, Date.class);
	}

}
