package com.gerimedica.exam.controller;

import com.gerimedica.exam.model.PatientRecord;
import com.gerimedica.exam.service.FileUploadService;
import com.gerimedica.exam.service.PatientRecordService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PatientRecordController.class)
class PatientRecordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PatientRecordService patientRecordService;

    @MockBean
    private FileUploadService fileUploadService;

    @Test
    void testFetchAll() throws Exception {
        when(patientRecordService.getRecords()).thenReturn(getTestRecords());
        mockMvc.perform(get("/record"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty())
                .andExpect(jsonPath("$[0].code").isNotEmpty())
                .andExpect(jsonPath("$[1].code").isNotEmpty())
        ;
    }

    @Test
    void testFetchByCode() throws Exception {
        String code = "123";
        PatientRecord patientRecord = new PatientRecord();
        patientRecord.setCode(code);
        when(patientRecordService.getByCode(anyString())).thenReturn(patientRecord);
        mockMvc.perform(get("/record/" + code))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty())
                .andExpect(jsonPath("$.code").exists())
                .andExpect(jsonPath("$.code").value(code))
        ;
    }

    @Test
    void testDelete() throws Exception {
        String code = "123";
        doNothing().when(patientRecordService).deleteAllRecords();
        mockMvc.perform(delete("/record"))
                .andDo(print())
                .andExpect(status().isNoContent())
        ;
    }

    private List<PatientRecord> getTestRecords() {
        List<PatientRecord> patientRecords = new ArrayList<>();
        PatientRecord patientRecord1 = new PatientRecord();
        patientRecord1.setCode("123");
        PatientRecord patientRecord2 = new PatientRecord();
        patientRecord2.setCode("456");
        patientRecords.add(patientRecord1);
        patientRecords.add(patientRecord2);
        return patientRecords;
    }

}